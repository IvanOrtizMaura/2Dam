package cide.interfaces;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;

public class SimonDiceController {
    @FXML
    public Button btn4;

    @FXML
    public Label lblPuntuacion;

    // public void start() {
    // Boolean bandera = true;
    // while (bandera) {
    // if (turnoSimon() != turnoJugador()) {
    // lblPuntuacion.setText("Has perdido");
    // bandera = false;
    // }
    // }

    // }

    private void turnoJugador() {
        // Creamos una array para guardar la eleccion del jugador

        // Guardamos la eleccion del jugador a la array

        // Le devolvemos el contenido de la array para poder comprobar el contenido de
        // la maquina y sea igual que el de la maquina
    }

    private void turnoSimon() {
        // Creamos una array para guardar la eleccion de la maquina

        // Creamos un bucle

        // Guardamos la seleccion en la array

        // Devolvemos el contenido de la array para que el if compruebe que es lo mismo
        // que lo que ha elegido el jugador
    }

    public void instrucciones() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setTitle("Intrucciones");
        alert.setContentText(
                "Edad minima: 6 años \n\nÚnico jugador \n\nPresiono el boton start para empezar la partida y se te mostrará una secuenca de colores. Acierta la secuencia y consiguirás convertire en el ganador de la partida");
        alert.showAndWait();
    }

    public void puntuar() {
        int contador = (Integer.parseInt(lblPuntuacion.getText())) + 1;
        lblPuntuacion.setText(String.valueOf(contador));
        if (contador == 10) {
            lblPuntuacion.setText("Has ganado");
        }
        
    }

}
